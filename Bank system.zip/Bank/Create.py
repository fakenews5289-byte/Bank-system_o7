accounts = {}

def create_account():
    number = input("Account number: ").strip()
    if not number or number in accounts:
        print("Invalid or duplicate account number.")
        return

    name = input("Customer name: ").strip()
    phone = input("Phone number: ").strip()
    kind = input("Account type (Savings/Current): ").strip().title()

    if not name or not phone.isdigit() or kind not in ("Savings", "Current"):
        print("Invalid customer details.")
        return

    try:
        balance = float(input("Initial deposit (min Rs. 500): "))
        if balance < 500:
            print("Minimum deposit is Rs. 500.")
            return
    except ValueError:
        print("Enter a valid amount.")
        return

    accounts[number] = {
        "name": name, "phone": phone, "type": kind,
        "balance": balance, "status": "Active"
    }
    print("Account created.")

def find_account():
    number = input("Account number: ").strip()
    account = accounts.get(number)
    if not account:
        print("Account not found.")
    return number, account

def deposit():
    number, account = find_account()
    if account and account["status"] == "Active":
        try:
            amount = float(input("Deposit amount: "))
            if amount <= 0:
                raise ValueError
            account["balance"] += amount
            print("Deposit successful.")
        except ValueError:
            print("Enter an amount greater than zero.")

def withdraw():
    number, account = find_account()
    if not account or account["status"] != "Active":
        return
    try:
        amount = float(input("Withdrawal amount: "))
        minimum = 500 if account["type"] == "Savings" else 0
        if amount <= 0 or account["balance"] - amount < minimum:
            print("Invalid amount or insufficient balance.")
            return
        account["balance"] -= amount
        print("Withdrawal successful.")
    except ValueError:
        print("Enter a valid amount.")

def transfer():
    sender_no, sender = find_account()
    if not sender:
        return
    receiver_no = input("Receiver account number: ").strip()
    receiver = accounts.get(receiver_no)

    if not receiver or receiver["status"] != "Active" or sender["status"] != "Active":
        print("Invalid or inactive account.")
        return
    if sender_no == receiver_no:
        print("Choose a different receiver account.")
        return

    try:
        amount = float(input("Transfer amount: "))
        minimum = 500 if sender["type"] == "Savings" else 0
        if amount <= 0 or sender["balance"] - amount < minimum:
            print("Invalid amount or insufficient balance.")
            return
        sender["balance"] -= amount
        receiver["balance"] += amount
        print("Transfer successful.")
    except ValueError:
        print("Enter a valid amount.")

def search():
    print("1. Account number  2. Customer name  3. Phone number")
    choice = input("Search option: ").strip()
    query = input("Search value: ").strip().lower()
    if choice not in ("1", "2", "3") or not query:
        print("Invalid search input.")
        return

    key = {"1": None, "2": "name", "3": "phone"}[choice]
    matches = []
    for number, account in accounts.items():
        value = number if key is None else account[key]
        if query in value.lower():
            matches.append((number, account))

    if not matches:
        print("No account found.")
    for number, a in matches:
        print(number, a["name"], a["phone"], a["type"],
              a["status"], f'Rs. {a["balance"]:.2f}')

while True:
    print("\n1. Create Account\n2. Deposit Money\n3. Withdraw Money")
    print("4. Transfer Money\n5. Search Account\n6. Exit")
    choice = input("Choose: ").strip()

    if choice == "1":
        create_account()
    elif choice == "2":
        deposit()
    elif choice == "3":
        withdraw()
    elif choice == "4":
        transfer()
    elif choice == "5":
        search()
    elif choice == "6":
        print("Thank you for using the Bank Account.")
        break
    else:
        print("Please choose a valid menu option.")